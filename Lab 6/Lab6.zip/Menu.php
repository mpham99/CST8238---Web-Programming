<?php
echo "<div id =\"menu\">";
echo "<button class = \"menuButton\">Dropdown Menu</button>";
echo "<div class = \"menuOption\">";
echo "<p><a href =\"http://minhducpham.com/CST8238/Lab6/index.php\">Index</a></p><br>";
echo "<p><a href =\"http://minhducpham.com/CST8238/Lab6/DivideByThree.php\">DivideByThree</a></p><br>";
echo "<p><a href =\"http://minhducpham.com/CST8238/Lab6/Random.php\">Random</a></p><br>";
echo "<p><a href =\"http://minhducpham.com/CST8238/Lab6/Pattern.php\">Pattern<a></p><br>";
echo "</div>";
echo "</div>";
?>

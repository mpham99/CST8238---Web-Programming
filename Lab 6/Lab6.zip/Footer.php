<?php
echo "<div id = \"footer\">";
echo "<p>Student Number: 040905103 | First Name: Minh Duc | Last Name: Pham | Email Address: pham0112@algonquinlive.com</p>";
echo "</div>";
?>

<?php
echo "<div id=\"header\">";
echo "<h1>";
echo "<span id = \"title\">Lab 6</span>";
echo "</h1>";
echo "</div>";
?>

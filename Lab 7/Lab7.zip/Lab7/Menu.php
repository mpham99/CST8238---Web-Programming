<?php
echo "<div id =\"menu\">";
echo "<button class = \"menuButton\">Dropdown Menu</button>";
echo "<div class = \"menuOption\">";
echo "<p><a href =\"http://minhducpham.com/CST8238/Lab7/Array1.php\">Array1</a></p><br>";
echo "<p><a href =\"http://minhducpham.com/CST8238/Lab7/Array2.php\">Array2</a></p><br>";
echo "<p><a href =\"http://minhducpham.com/CST8238/Lab7/Object.php\">Object</a></p><br>";
echo "</div>";
echo "</div>";
?>

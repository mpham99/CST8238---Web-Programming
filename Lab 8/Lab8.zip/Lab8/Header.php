<?php
echo "<div id=\"header\">";
echo "<h1>";
echo "<span id = \"title\">CST8238 Web Programming</span>";
echo "</h1>";
echo "</div>";
?>

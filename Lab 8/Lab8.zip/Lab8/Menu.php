<?php
echo "<div id =\"menu\">";
echo "<button class = \"menuButton\">Dropdown Menu</button>";
echo "<div class = \"menuOption\">";
echo "<p><a href =\"Input.php\">Input</a></p><br>";
echo "<p><a href =\"Session1.php\">Session1</a></p><br>";
echo "<p><a href =\"Session2.php\">Session2</a></p><br>";
echo "</div>";
echo "</div>";
?>
